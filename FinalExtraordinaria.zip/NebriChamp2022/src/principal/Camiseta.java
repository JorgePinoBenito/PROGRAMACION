package principal;

public class Camiseta extends Equipacion {
	
	public Camiseta() {}

}
