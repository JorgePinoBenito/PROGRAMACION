package principal;

public abstract class Equipacion {
	public Equipacion() {}
	
	
	
	
}
