package principal;

import java.util.ArrayList;

public class Liga {

	public static void main(String[] args) {
		ArrayList<Equipo>equipos=new ArrayList<Equipo>();
		int contadordeequipos;
		String nombre="NebriChamp2022";
		
		Menu menu=new Menu();
		menu.printMenu();
		
		
		

	}
	
	

}
