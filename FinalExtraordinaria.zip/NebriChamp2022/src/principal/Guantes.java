package principal;

public class Guantes extends Equipacion {
	
	public Guantes() {}

}
