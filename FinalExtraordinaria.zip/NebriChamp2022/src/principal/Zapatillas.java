package principal;

public class Zapatillas extends Equipacion{
	
	public Zapatillas() {}

}
