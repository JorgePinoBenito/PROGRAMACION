package principal;

public class Pantalon extends Equipacion{
	
	public Pantalon() {}

}
