List of exercise example of design pattern

- Singleton
- Strategy
- Factory
- Abstract Factory
- Facade
- Command
- Adapter
- Decorator
- Composite
- Proxy
- State
- Template

References
1. https://www.youtube.com/playlist?list=PLrhzvIcii6GNjpARdnO4ueTUAVR9eMBpc
2. https://medium.com/@arjunsk/design-pattern-in-java-bafd91a5d24e